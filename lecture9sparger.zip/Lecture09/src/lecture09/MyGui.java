package lecture09;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class MyGui extends JFrame {

	JLabel jlSal, jlTR, jlTax; 
	JTextField jtfSal, jtfTR, jtfTax;
	JButton jbnCompute, jbnClear, jbnExit; 
	public MyGui(){
		Container c = getContentPane();
		c.setLayout(new GridLayout(5,2));
		/*
		 * GridLayout myLayout = new GridLayout (5,2); 
		 * c.setLayout(myLayout);
		 */
		
		//label
		jlSal = new JLabel("Enter your Salary: "); //JLabel jlSal = New JLabel ()
		jtfSal = new JTextField();
		jlTR = new JLabel("Enter Tax Rate: ");
		jtfTR = new JTextField ();
		jlTax = new JLabel ("Your Tax is: ");
		jtfTax = new JTextField ();
		jbnCompute = new JButton ("Compute");
		jbnClear = new JButton("Clear");
		jbnExit = new JButton("Exit");
		c.add(jlSal);
		c.add(jtfSal);
		c.add(jlTR);
		c.add(jtfTR);
		c.add(jlTax);
		c.add(jtfTax);
		c.add(jbnCompute);
		c.add(jbnClear);
		c.add(jbnExit);
		ButtonHandler myH = new ButtonHandler();
		jbnCompute.addActionListener(myH);
		jbnClear.addActionListener(myH);
		jbnExit.addActionListener(myH);
		pack();
		setVisible(true);
	}
	
	public class ButtonHandler implements ActionListener {
		public void actionPerformed(ActionEvent e){
			if (e.getSource()==jbnCompute){
				double income, tax, rate;
				income = Double.parseDouble(jtfSal.getText());
				rate = Double.parseDouble(jtfTR.getText());
				tax = income * rate/100.00;
				jtfTax.setText(String.valueOf(tax));
			}
			if (e.getSource()==jbnClear){
				jtfSal.setText("");
				jtfTR.setText("");
				jtfTax.setText("");
			}
			if (e.getSource()==jbnExit){
				System.exit(0);
			}
		}
	}
}
