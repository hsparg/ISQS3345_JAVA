package lecture09;

public class MyApp {

	public static void main(String[] args){
		MyGui myFirst = new MyGui();
	}
}
