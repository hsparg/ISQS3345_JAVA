package DisplayName;

public class MyApp {
	public static void main(String[] args){
		MyGui nameGui = new MyGui();
	}
}
