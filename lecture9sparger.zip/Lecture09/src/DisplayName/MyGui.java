package DisplayName;

import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import lecture09.MyGui.ButtonHandler;

public class MyGui {
	JLabel jlName; 
	JTextField jtfName, jtfDname;
	JButton jbnDisplay, jbnClear;
}
public MyGui(){
	Container c = getContentPane();
	c.setLayout(new GridLayout(5,2));
	/*
	 * GridLayout myLayout = new GridLayout (5,2); 
	 * c.setLayout(myLayout);
	 */
	
	//label
	jlName = new JLabel("Name: "); //JLabel jlSal = New JLabel ()
	jtfName = new JTextField();
	jlTR = new JLabel("Enter Tax Rate: ");
	jtfTR = new JTextField ();
	jlTax = new JLabel ("Your Tax is: ");
	jtfTax = new JTextField ();
	jbnCompute = new JButton ("Compute");
	jbnClear = new JButton("Clear");
	jbnExit = new JButton("Exit");
	c.add(jlSal);
	c.add(jtfSal);
	c.add(jlTR);
	c.add(jtfTR);
	c.add(jlTax);
	c.add(jtfTax);
	c.add(jbnCompute);
	c.add(jbnClear);
	c.add(jbnExit);
	ButtonHandler myH = new ButtonHandler();
	jbnCompute.addActionListener(myH);
	jbnClear.addActionListener(myH);
	jbnExit.addActionListener(myH);
	pack();
	setVisible(true);
